####Author: Sadie Lombardi, slombardi@wpi.edu

Title: EscapeStarter

Date: 12/16/21

###Import into Eclipse:
Copy all files under the top level into an existing Eclipse project.